<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ApartmentPriceIntervals extends Model
{
    use HasFactory;
    protected $table = 'apartment_price_intervals';
}
